//
//  ViewController.swift
//  Swift3_Webservice
//
//  Created by alpesh patel on 12/29/16.
//  Copyright © 2016 alpesh patel. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        self.TestingService(localMobileNumber: "")
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


    func TestingService(localMobileNumber:String) {
        
        
        if Constant.isReachable == false {
            
            UserDefaults.standard.setValue(12, forKey:"caregiver_id")
            
            
        let parameters : NSDictionary = [
            "caregiver_id" : UserDefaults.standard.value(forKey: "caregiver_id") as! NSInteger!
            ]
        
            let webService = Webservice()
        
            webService.delegate = self
            webService.RequestForPost(url: "http://appadmin.nuevacare.com/backend/web/index.php/caregiverservice/newshift-available", postData: parameters as! [String : Any] as NSDictionary, apiIdentifier: "Testing")
        } else {
            let alert = UIAlertController(title: "Testing", message: Constant.InternetConnectionProblem, preferredStyle: UIAlertControllerStyle.alert)
            alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler:nil))
            present(alert, animated: true, completion: nil)
        }
    }

    
}


extension ViewController : WebserviceDelegate{

    func webserviceResponseSuccess(response: NSDictionary, apiIdentifier: String) {
        
        if apiIdentifier == "Testing" {
            
         
        }
    }
    
    func webserviceResponseFail(response: NSDictionary, apiIdentifier: String) {
      
        if apiIdentifier == "Testing" {
            
            
           
        }
    }
    
    func webserviceResponseError(error: Error?, apiIdentifier: String) {
       
    
    }

    
}

