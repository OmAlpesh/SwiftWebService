//
//  Constant.swift
//  ARDWM
//
//  Created by Uday on 12/02/16.
//  Copyright © 2016 Credencys. All rights reserved.
//

import UIKit

class Constant: NSObject {
    
    static let InternetConnectionProblem : String = "Please check your internet connection."
    
    static let AccountProblemAlert : String =  "Oops!! Something went wrong. Please contact your RM."
    
    // MARK: - Server Domain
    static var SIT : String = "http://wmsit.rathi.com"
    static var UAT : String = "https://wmuat.rathi.com"
    static var Production : String = "https://wm.rathi.com"
    
    // MARK: - ServerPath Version 1
    static var ServerPathV1 : String = "\(UAT)/WMService/api/v1/"
    
    // MARK: - ServerPath Version 2
    static var ServerPathV2 : String = "\(UAT)/WMService/api/v2/"
    
    // MARK: - ServerPath Version 3
    static var ServerPathV3 : String = "\(UAT)/WMService/api/v3/"
    
    // MARK: - AWS
    static var AWSACCESSKEY : String = "AKIAJYLYDU3SKLO3HSWQ"
    static var AWSSECRETKEY : String = "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"
    static var AWSBUCKET : String = "ardwmvideos"
    
    static let defaults = UserDefaults.standard
    // MARK: - Language ID
    static var LanguageID : String = "619001"
    // MARK: - Humor ID
    static var HumorID : String = "620002"
    // MARK: - DB Version
    static var DatabaseVersion : Int = 1
    // MARK: - OrderID Token
    static var OrderID : String = ""
    // MARK: - TransactionTypeID Token
    static var TransactionTypeID : String = ""
    // MARK: - MAC UUID Token
    //static var MacUUID : String = UIDevice.current.identifierForVendor!.uuidString
    static var MacUUID : String = "00:0a:95:9d:68:16"
    
    // MARK: - Device Token
    static var deviceToken : String = ""
    // MARK: - User ID
    static var userID      : String = ""
    // MARK: - Party ID
    static var partyID      : String = ""
    // MARK: - Device Token
    static var Product_ID : String = ""
    // MARK: - AppDel Shared Object
    static var AppDel = UIApplication.shared.delegate as! AppDelegate
    // MARK: - Wealth Investment Param
    static var Curr_Wealth : Double?
    static var Ann_Saving  : Double?
    static var Equity      : Double?
    static var Debt        : Double?
    static var putOption   : Int = 1
    static var YearValue   : Int = 25
    // MARK: - CurrentWealth And AnnualSaving Arr List
    static var arrCurrentWealth:NSMutableArray?
    static var arrAnualSaving:NSMutableArray?
    // MARK: - Check Which Video File
    static var FromViewController  : Int?
    static var UnderRiskOrStrategy : Int?
    // MARK: - Reachablity Check
    static var isReachable      :   Bool   = false
    static var isPlayVideoFullScreen : Bool = false
    static var isOnWiFi: Bool = false
    // MARK: - Screen Size
    static var kScreenBounds    :   CGRect = UIScreen.main.bounds
    static var isiPhone_4       :   Bool   = 480 == UIScreen.main.bounds.size.height ? true:false
    static var isiPhone_5       :   Bool   = 568 == UIScreen.main.bounds.size.height ? true:false
    static var isiPhone_6       :   Bool   = 667 == UIScreen.main.bounds.size.height ? true:false
    static var isiPhone_6_Plus  :   Bool   = 736 == UIScreen.main.bounds.size.height ? true:false
    
    // MARK: - Storyboard File
    static let DashboardStoryboard : UIStoryboard = UIStoryboard(name: "Dashboard", bundle: nil)
    static let OpeNAccountStoryboard : UIStoryboard = UIStoryboard(name: "OpenAccount", bundle: nil)
    static let ManageStrategyStoryboard : UIStoryboard = UIStoryboard(name: "ManageStrategy", bundle: nil)
    static let SignUpStoryboard : UIStoryboard = UIStoryboard(name: "SignUp", bundle: nil)
    static let SnapshotStoryboard : UIStoryboard = UIStoryboard(name: "SnapshotDashboard", bundle: nil)
    
    
    // MARK: - Navigation Method's
    //, isPushOrPop:Bool
    static func Push_Pop_to_ViewController(destinationVC:UIViewController,isAnimated:Bool,navigationController:UINavigationController){
        var VCFound:Bool = false
        let viewControllers:NSArray = (navigationController.viewControllers as NSArray)
        var indexofVC:NSInteger = 0
        for  vc  in viewControllers {
            if (vc as AnyObject).nibName == (destinationVC.nibName) {
                VCFound = true
                break
            } else {
                indexofVC += 1
            }
        }
        if VCFound == true {
            navigationController .popToViewController(viewControllers.object(at: indexofVC) as! UIViewController, animated: isAnimated)
        } else {
            DispatchQueue.main.async {
                navigationController .pushViewController(destinationVC , animated: isAnimated)
            }
        }
    }
    
    
    static func RemoveViewControllerFromStack(destinationVC:UIViewController,navigationController:UINavigationController){
        let viewControllers:NSArray = (navigationController.viewControllers as NSArray)
        var indexofVC:NSInteger = 0
        for  vc  in viewControllers {
            if (vc as AnyObject).nibName == (destinationVC.nibName) {
                (vc as AnyObject).removeFromParentViewController()
                break
            } else {
                indexofVC += 1
            }
        }
    }
    
    
    static func getDocumentsURL() -> URL {
        let documentsURL = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        return documentsURL
    }
    
    static func fileInDocumentsDirectory(filename: String) -> String {
        let fileURL = getDocumentsURL().appendingPathComponent(filename)
        return fileURL.path
    }
    
    static func getUniqueString() -> String {
        let df: DateFormatter = DateFormatter()
        df.dateFormat = "ddMMyyyHHmmssSSS"
        return df.string(from: NSDate() as Date)
    }
    
    //MARK:- Validation
    static func usernameValidation(strUsername:String)->Bool {
        // Usernam should not blank
        if strUsername.isEmpty {
            return false
        }
        //Username should not be more than 40 characters.
        if strUsername.characters.count >= 40{
            return false
        }
        //Username should not contain space
        if strUsername.contains(" ") {
            return false
        }
        //Username should not start with any symbols.
        let regEx = "^([a-zA-z0-9])"
        let match = strUsername.range(of: regEx, options: .regularExpression, range: nil, locale: nil)
        if (match == nil){
            return false
        }
        return true
        //Username should not accept with spacing word(like word:user test)
    }
    
    //MARK passwodValidation
    static func passwodValidation(strPasswd : String)-> Bool {
        // Password should not blank
        if strPasswd.isEmpty {
            return false
        }
        //Password should be at least 6 characters.
        if strPasswd.characters.count < 6{
            return false
        }
        //Password should not be more than 40 characters.
        if strPasswd.characters.count > 40{
            return false
        }
        //Password should not contain space
        if strPasswd.contains(" "){
            return false
        }
        return true
    }
    
    //MARK emailAdrressValidation
    static func emailAdrressValidation(strEmail : String)->Bool {
        // Password should not blank
        if strEmail.isEmpty{
            return false
        }
        //Email address should accept like:test@gmail.co.uk
        let emailRegEx = "[.0-9a-zA-Z_-]+@[0-9a-zA-Z.-]+\\.[a-zA-Z]{2,20}"
        let emailTest = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
        
        if !emailTest.evaluate(with: strEmail){
            return false
        }
        return true
    }
    
    static func setPalceHolderTextColor(textFiled:UITextField, text:String) {
        textFiled.attributedPlaceholder = NSAttributedString(string:text, attributes:[NSForegroundColorAttributeName: UIColor.init(colorLiteralRed: 254/255, green: 254/255, blue: 254/255, alpha: 0.20)])
        
    }
    
    static func convertStringToDictionary(text: String) -> NSDictionary? {
        if let data = text.data(using: String.Encoding.utf8) {
            do { return try JSONSerialization.jsonObject(with: data, options: []) as? [String:AnyObject] as NSDictionary?
            } catch let error as NSError { print(error) }
        }
        return nil
    }
    
    static func getDaysDifferance(_ dateTime:String) -> String {
        let dateFormate = DateFormatter()
        dateFormate.dateFormat = "dd/MM/yyyy HH:mm:ss"
        dateFormate.timeZone = NSTimeZone(name: "UTC") as TimeZone!
        let tempPassedDate = dateFormate.date(from: dateTime)
        
        let displatyDataFormate = DateFormatter()
        displatyDataFormate.dateFormat = "EEE, dd MMM yyyy"
        displatyDataFormate.timeZone = NSTimeZone.local
        
        let DateString = displatyDataFormate.string(from: tempPassedDate!)
        let passedDate = displatyDataFormate.date(from: DateString)
        
        //***let passedDate = dateFormate.date(from: dateTime)***//
        let todayDate = NSDate()
        if todayDate.compare(passedDate!) == .orderedSame {
            return "Today"
        }
        else {
            let timeInterval = todayDate.timeIntervalSince(passedDate!)
            if timeInterval / (24 * 60 * 60) == 2 {
                return "Yesterday"
            }
            else {
                return displatyDataFormate.string(from: passedDate!)
            }
        }
    }
    
    static func getDaysMessageDifferance(_ dateTime:String) -> String {
        
        let tempDateFormate = DateFormatter()
        tempDateFormate.dateFormat = "dd/MM/yyyy HH:mm:ss"
        tempDateFormate.timeZone = NSTimeZone(name: "UTC") as TimeZone!
        let tempPassedDate = tempDateFormate.date(from: dateTime)
        
        let dateFormate = DateFormatter()
        dateFormate.timeZone = NSTimeZone.local
        dateFormate.dateFormat = "dd/MM/yyyy"
        
        let displatyDataFormate = DateFormatter()
        displatyDataFormate.timeZone = NSTimeZone.local
        
        let passedDate = dateFormate.date(from: dateTime.components(separatedBy: " ")[0])
        
        let todayDateStr = dateFormate.string(from: NSDate() as Date)
        let todayDate = dateFormate.date(from: todayDateStr)
        
        if todayDate?.compare(passedDate!) == .orderedSame {
            displatyDataFormate.dateFormat = "hh:mm a"
        }
        else {
            displatyDataFormate.dateFormat = "dd MMM"
        }
        return displatyDataFormate.string(from: tempPassedDate!)
    }
    
    
    static func setAttributedText(mainString : String, primaryFontName : String, secondaryFontName : String, MainFontSize:CGFloat, SubFontSize:CGFloat, subStringLength : Int) -> NSMutableAttributedString {
        
        let AttributedString = NSMutableAttributedString(
            string: mainString,
            attributes: [NSFontAttributeName:UIFont(
                name: primaryFontName,
                size: MainFontSize)!])
        
        AttributedString.addAttribute(NSFontAttributeName,
                                      value: UIFont(
                                        name: primaryFontName,
                                        size: MainFontSize)!,
                                      range: NSRange(
                                        location: 0,
                                        length: mainString.characters.count - subStringLength))
        
        AttributedString.addAttribute(NSFontAttributeName,
                                      value: UIFont(
                                        name: secondaryFontName,
                                        size: SubFontSize)!,
                                      range: NSRange(
                                        location: mainString.characters.count - subStringLength,
                                        length: subStringLength))
        return AttributedString
    }
}
